package com.example.flutter_github_builder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
