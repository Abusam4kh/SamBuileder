# Flutter GitHub Builder

تطبيق Android مبني بـ Flutter لإدارة مشاريع Flutter من الهاتف عبر GitHub.

- ربط GitHub باستخدام Personal Access Token
- SQLite للمشاريع المحلية
- إنشاء Repository لكل مشروع
- رفع ملفات Flutter وGitHub Actions
- تشغيل Build APK من التطبيق
