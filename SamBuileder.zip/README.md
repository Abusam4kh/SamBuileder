# Flutter GitHub Builder
تطبيق Android مكتوب بـ Flutter/Dart لإنشاء مشاريع Flutter من الهاتف ورفعها إلى GitHub وتشغيل GitHub Actions لبناء APK.

## طريقة العمل
1. افتح "ربط GitHub".
2. أدخل GitHub Personal Access Token مرة واحدة.
3. أنشئ مشروعاً؛ التطبيق ينشئ مستودعاً مستقلاً ويرفع ملفات Flutter الأساسية.
4. افتح المشروع واضغط "بناء APK الآن".
5. GitHub Actions يبني `app-release.apk` ويرفعه كـ Artifact.
