# Flutter GitHub Builder

تطبيق Android مبني بـ Flutter لإدارة مشاريع Flutter من الهاتف عبر GitHub.

- ربط GitHub باستخدام Personal Access Token
- SQLite للمشاريع المحلية
- إنشاء Repository لكل مشروع
- رفع ملفات Flutter وGitHub Actions
- تشغيل Build APK من التطبيق

## Android build compatibility

The Android Gradle project is generated during GitHub Actions with Flutter 3.38.1.
This avoids the unsupported Gradle project error caused by the legacy Android
folder that was previously included in the project.
