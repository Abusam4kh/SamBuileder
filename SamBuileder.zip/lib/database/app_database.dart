import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/project.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    final path = join(dir, 'flutter_github_builder.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE projects (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          repo_name TEXT NOT NULL,
          owner TEXT NOT NULL,
          repo_url TEXT NOT NULL,
          created_at TEXT NOT NULL,
          status TEXT NOT NULL
        )
      ''');
    });
    return _db!;
  }
  Future<List<Project>> projects() async {
    final db = await database;
    final rows = await db.query('projects', orderBy: 'id DESC');
    return rows.map(Project.fromMap).toList();
  }
  Future<Project> insertProject(Project project) async {
    final db = await database;
    final values = project.toMap()..remove('id');
    final id = await db.insert('projects', values);
    return Project(id: id, name: project.name, repoName: project.repoName,
      owner: project.owner, repoUrl: project.repoUrl, createdAt: project.createdAt,
      status: project.status);
  }
  Future<Project?> getProject(int id) async {
    final db = await database;
    final rows = await db.query('projects', where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : Project.fromMap(rows.first);
  }
}
