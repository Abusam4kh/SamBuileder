import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/project.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    _database ??= await _open();
    return _database!;
  }

  Future<Database> _open() async {
    final base = await getDatabasesPath();
    return openDatabase(
      p.join(base, 'flutter_github_builder.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            repo_name TEXT NOT NULL,
            owner TEXT NOT NULL,
            repo_url TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<List<Project>> getProjects() async {
    final rows = await (await database).query('projects', orderBy: 'id DESC');
    return rows.map(Project.fromMap).toList();
  }

  Future<int> insertProject(Project project) async =>
      (await database).insert('projects', project.toMap());

  Future<int> deleteProject(int id) async =>
      (await database).delete('projects', where: 'id = ?', whereArgs: [id]);
}
