import 'package:flutter/material.dart';
class AppScaffold extends StatelessWidget {
  const AppScaffold({super.key, required this.title, required this.body, this.floatingActionButton});
  final String title;
  final Widget body;
  final Widget? floatingActionButton;
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: Text(title)), body: body, floatingActionButton: floatingActionButton),
  );
}
