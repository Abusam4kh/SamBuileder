import 'package:flutter/material.dart';
import '../services/github_auth_service.dart';
import '../models/github_user.dart';
import '../widgets/app_scaffold.dart';

class GithubScreen extends StatefulWidget {
  const GithubScreen({super.key});
  @override State<GithubScreen> createState() => _GithubScreenState();
}
class _GithubScreenState extends State<GithubScreen> {
  final controller = TextEditingController();
  GithubUser? user; bool loading = true; bool saving = false; String? error;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final u = await GithubAuthService.instance.currentUser();
    if (mounted) setState(() { user = u; loading = false; });
  }
  Future<void> _connect() async {
    setState(() { saving = true; error = null; });
    try {
      final u = await GithubAuthService.instance.validateAndSaveToken(controller.text);
      if (mounted) { setState(() { user = u; controller.clear(); }); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم ربط GitHub بنجاح.'))); }
    } catch (e) { if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => saving = false); }
  }
  Future<void> _disconnect() async { await GithubAuthService.instance.disconnect(); if (mounted) setState(() => user = null); }
  @override Widget build(BuildContext context) => AppScaffold(
    title: 'ربط GitHub',
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
      if (user != null) ...[
        CircleAvatar(radius: 38, backgroundImage: user!.avatarUrl.isEmpty ? null : NetworkImage(user!.avatarUrl),
          child: user!.avatarUrl.isEmpty ? const Icon(Icons.person, size: 40) : null),
        const SizedBox(height: 12),
        Center(child: Text('@${user!.login}', style: Theme.of(context).textTheme.titleLarge)),
        if (user!.name.isNotEmpty) Center(child: Text(user!.name)),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: _disconnect, icon: const Icon(Icons.link_off), label: const Text('إلغاء ربط GitHub')),
      ] else ...[
        const Icon(Icons.code, size: 72),
        const SizedBox(height: 12),
        Text('اربط حساب GitHub مرة واحدة', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 10),
        const Text('أدخل GitHub Personal Access Token. يجب أن يملك صلاحية إنشاء المستودعات وكتابة Contents وWorkflows.', textAlign: TextAlign.center),
        const SizedBox(height: 20),
        TextField(controller: controller, obscureText: true, decoration: const InputDecoration(labelText: 'GitHub Personal Access Token', prefixIcon: Icon(Icons.key))),
        const SizedBox(height: 12),
        if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        const SizedBox(height: 8),
        FilledButton(onPressed: saving ? null : _connect, child: saving ? const CircularProgressIndicator() : const Text('ربط الحساب')),
      ],
    ]),
  );
}
