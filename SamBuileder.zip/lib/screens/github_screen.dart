import 'package:flutter/material.dart';
import '../models/github_user.dart';
import '../services/github_auth_service.dart';
import '../services/github_service.dart';

class GithubScreen extends StatefulWidget {
  const GithubScreen({super.key});
  @override
  State<GithubScreen> createState() => _GithubScreenState();
}

class _GithubScreenState extends State<GithubScreen> {
  final controller = TextEditingController();
  GithubUser? user;
  String? error;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!await GithubAuthService.instance.isConnected()) return;
    try {
      final u = await GithubService.instance.getCurrentUser();
      if (mounted) setState(() => user = u);
    } catch (_) {}
  }

  Future<void> _connect() async {
    final token = controller.text.trim();
    if (token.isEmpty) {
      setState(() => error = 'أدخل GitHub Personal Access Token.');
      return;
    }
    setState(() { loading = true; error = null; });
    try {
      await GithubAuthService.instance.saveToken(token);
      final u = await GithubService.instance.getCurrentUser();
      if (mounted) setState(() => user = u);
    } catch (e) {
      await GithubAuthService.instance.deleteToken();
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _disconnect() async {
    await GithubAuthService.instance.deleteToken();
    if (mounted) setState(() { user = null; controller.clear(); });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ربط GitHub')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (user != null) ...[
          CircleAvatar(
            radius: 38,
            backgroundImage: user!.avatarUrl != null ? NetworkImage(user!.avatarUrl!) : null,
            child: user!.avatarUrl == null ? const Icon(Icons.person, size: 40) : null,
          ),
          const SizedBox(height: 12),
          Text(user!.name?.isNotEmpty == true ? user!.name! : user!.login,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge),
          Text('@${user!.login}', textAlign: TextAlign.center),
          const SizedBox(height: 24),
          FilledButton.icon(onPressed: _disconnect, icon: const Icon(Icons.logout), label: const Text('فصل الحساب')),
        ] else ...[
          const Icon(Icons.code, size: 70),
          const SizedBox(height: 16),
          Text('اربط حساب GitHub', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 10),
          const Text('أدخل Personal Access Token وسيتم حفظه في التخزين الآمن.', textAlign: TextAlign.center),
          const SizedBox(height: 24),
          TextField(
            controller: controller,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'GitHub Token', border: OutlineInputBorder(), prefixIcon: Icon(Icons.key)),
          ),
          const SizedBox(height: 12),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: loading ? null : _connect,
            icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.link),
            label: Text(loading ? 'جارٍ التحقق...' : 'ربط الحساب'),
          ),
        ],
      ],
    ),
  );

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}
