import 'package:flutter/material.dart';
import '../services/project_service.dart';
import '../widgets/app_scaffold.dart';

class CreateProjectScreen extends StatefulWidget {
  const CreateProjectScreen({super.key});
  @override State<CreateProjectScreen> createState() => _CreateProjectScreenState();
}
class _CreateProjectScreenState extends State<CreateProjectScreen> {
  final name = TextEditingController(), repo = TextEditingController(), description = TextEditingController();
  bool isPrivate = true, busy = false; String progress = '';
  String _repoName(String value) {
    var s = value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9._-]'), '-');
    s = s.replaceAll(RegExp(r'-+'), '-').replaceAll(RegExp(r'^[-.]+|[-.]+$'), '');
    return s.isEmpty ? 'flutter-project' : s;
  }
  Future<void> _create() async {
    if (name.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب اسم المشروع.'))); return; }
    setState(() { busy = true; progress = 'بدء العملية...'; });
    try {
      final project = await ProjectService().createProject(
        name: name.text.trim(), repoName: _repoName(repo.text.isEmpty ? name.text : repo.text),
        description: description.text.trim(), isPrivate: isPrivate,
        onProgress: (m) { if (mounted) setState(() => progress = m); },
      );
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء المشروع بنجاح.'))); Navigator.pop(context, project); }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => AppScaffold(title: 'مشروع Flutter جديد', body: ListView(padding: const EdgeInsets.all(20), children: [
    TextField(controller: name, onChanged: (v) { if (repo.text.isEmpty) repo.text = _repoName(v); }, decoration: const InputDecoration(labelText: 'اسم المشروع')),
    const SizedBox(height: 14),
    TextField(controller: repo, decoration: const InputDecoration(labelText: 'اسم مستودع GitHub')),
    const SizedBox(height: 14),
    TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف المشروع')),
    SwitchListTile(value: isPrivate, onChanged: busy ? null : (v) => setState(() => isPrivate = v), title: const Text('مستودع خاص')),
    if (busy) ...[const LinearProgressIndicator(), const SizedBox(height: 10), Text(progress, textAlign: TextAlign.center)],
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: busy ? null : _create, icon: const Icon(Icons.cloud_upload), label: const Text('إنشاء المستودع ورفع المشروع')),
  ]));
}
