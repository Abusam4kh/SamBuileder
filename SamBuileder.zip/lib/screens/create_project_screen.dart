import 'package:flutter/material.dart';
import '../services/project_service.dart';
import 'project_details_screen.dart';

class CreateProjectScreen extends StatefulWidget {
  const CreateProjectScreen({super.key});
  @override
  State<CreateProjectScreen> createState() => _CreateProjectScreenState();
}

class _CreateProjectScreenState extends State<CreateProjectScreen> {
  final name = TextEditingController();
  final repo = TextEditingController();
  final description = TextEditingController();
  bool privateRepo = true;
  bool loading = false;

  String repoName(String value) {
    var s = value.trim().toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_+|_+$'), '');
    if (s.isEmpty) s = 'flutter_project';
    if (RegExp(r'^[0-9]').hasMatch(s)) s = 'project_$s';
    return s;
  }

  Future<void> create() async {
    if (name.text.trim().isEmpty || repo.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم المشروع واسم Repository')));
      return;
    }
    setState(() => loading = true);
    try {
      final project = await ProjectService.instance.createProject(
        name: name.text.trim(),
        repoName: repo.text.trim(),
        description: description.text.trim(),
        isPrivate: privateRepo,
      );
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ProjectDetailsScreen(project: project)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مشروع جديد')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(
          controller: name,
          onChanged: (v) { if (repo.text.isEmpty) repo.text = repoName(v); },
          decoration: const InputDecoration(labelText: 'اسم المشروع', border: OutlineInputBorder(), prefixIcon: Icon(Icons.flutter_dash)),
        ),
        const SizedBox(height: 14),
        TextField(controller: repo, decoration: const InputDecoration(labelText: 'اسم Repository', border: OutlineInputBorder(), prefixIcon: Icon(Icons.storage))),
        const SizedBox(height: 14),
        TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'الوصف', border: OutlineInputBorder())),
        SwitchListTile(value: privateRepo, onChanged: (v) => setState(() => privateRepo = v), title: const Text('Repository خاص')),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: loading ? null : create,
          icon: loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.cloud_upload),
          label: Text(loading ? 'جارٍ الإنشاء والرفع...' : 'إنشاء المشروع'),
        ),
      ],
    ),
  );

  @override
  void dispose() {
    name.dispose(); repo.dispose(); description.dispose(); super.dispose();
  }
}
