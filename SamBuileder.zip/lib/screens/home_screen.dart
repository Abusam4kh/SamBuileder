import 'package:flutter/material.dart';
import '../models/project.dart';
import '../services/github_auth_service.dart';
import '../services/project_service.dart';
import 'create_project_screen.dart';
import 'github_screen.dart';
import 'project_details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Project> projects = [];
  bool connected = false;
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final c = await GithubAuthService.instance.isConnected();
    final p = await ProjectService.instance.getProjects();
    if (mounted) setState(() { connected = c; projects = p; loading = false; });
  }

  Future<void> github() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const GithubScreen()));
    await load();
  }

  Future<void> newProject() async {
    if (!connected) {
      await github();
      if (!connected) return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateProjectScreen()));
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Flutter GitHub Builder'), actions: [
      IconButton(onPressed: github, icon: const Icon(Icons.account_circle)),
    ]),
    floatingActionButton: FloatingActionButton.extended(onPressed: newProject, icon: const Icon(Icons.add), label: const Text('مشروع جديد')),
    body: loading
      ? const Center(child: CircularProgressIndicator())
      : RefreshIndicator(
          onRefresh: load,
          child: projects.isEmpty
            ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                children: [
                  const SizedBox(height: 80),
                  Icon(Icons.flutter_dash, size: 90, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 20),
                  Text('أنشئ مشروع Flutter من هاتفك', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 12),
                  const Text('اربط GitHub ثم أنشئ Repository لكل مشروع وشغّل GitHub Actions لبناء APK.', textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  FilledButton.icon(onPressed: github, icon: const Icon(Icons.link), label: Text(connected ? 'حساب GitHub مرتبط' : 'ربط GitHub')),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: projects.length,
                itemBuilder: (_, i) {
                  final p = projects[i];
                  return Card(child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.flutter_dash)),
                    title: Text(p.name),
                    subtitle: Text('${p.owner}/${p.repoName}\n${p.status}'),
                    isThreeLine: true,
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailsScreen(project: p))),
                  ));
                },
              ),
        ),
  );
}
