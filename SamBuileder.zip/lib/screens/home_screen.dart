import 'package:flutter/material.dart';
import '../database/app_database.dart';
import '../models/project.dart';
import '../services/github_auth_service.dart';
import '../widgets/app_scaffold.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  List<Project> projects = []; bool loading = true; bool connected = false;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await AppDatabase.instance.projects();
    final u = await GithubAuthService.instance.currentUser();
    if (mounted) setState(() { projects = p; connected = u != null; loading = false; });
  }
  Future<void> _openCreate() async {
    if (!connected) { await Navigator.pushNamed(context, '/github'); await _load(); if (!connected) return; }
    await Navigator.pushNamed(context, '/create'); await _load();
  }
  @override Widget build(BuildContext context) => AppScaffold(
    title: 'Flutter GitHub Builder',
    floatingActionButton: FloatingActionButton.extended(onPressed: _openCreate, icon: const Icon(Icons.add), label: const Text('مشروع جديد')),
    body: RefreshIndicator(onRefresh: _load, child: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(
        leading: Icon(connected ? Icons.cloud_done : Icons.cloud_off, color: connected ? Colors.green : Colors.orange),
        title: Text(connected ? 'GitHub متصل' : 'GitHub غير متصل'),
        subtitle: Text(connected ? 'يمكنك إنشاء مشروع جديد' : 'اضغط للربط'),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.pushNamed(context, '/github').then((_) => _load()),
      )),
      const SizedBox(height: 12),
      Text('مشاريعي', style: Theme.of(context).textTheme.titleLarge),
      if (projects.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('لا توجد مشاريع بعد.\nأنشئ أول مشروع من الزر أدناه.', textAlign: TextAlign.center))),
      ...projects.map((p) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.flutter_dash)), title: Text(p.name),
        subtitle: Text('${p.owner}/${p.repoName}'), trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.pushNamed(context, '/project', arguments: p.id),
      ))),
    ])),
  );
}
