import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/project.dart';
import '../services/project_service.dart';

class ProjectDetailsScreen extends StatefulWidget {
  final Project project;
  const ProjectDetailsScreen({super.key, required this.project});
  @override
  State<ProjectDetailsScreen> createState() => _ProjectDetailsScreenState();
}

class _ProjectDetailsScreenState extends State<ProjectDetailsScreen> {
  bool building = false;

  Future<void> openUrl(String value) async {
    final uri = Uri.tryParse(value);
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> buildApk() async {
    setState(() => building = true);
    try {
      await ProjectService.instance.buildProject(widget.project);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تشغيل GitHub Actions.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => building = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final actions = 'https://github.com/${widget.project.owner}/${widget.project.repoName}/actions';
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل المشروع')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.project.name, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text('${widget.project.owner}/${widget.project.repoName}'),
            const SizedBox(height: 8),
            Text(widget.project.status),
          ]))),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: building ? null : buildApk, icon: building ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow), label: Text(building ? 'جارٍ التشغيل...' : 'بناء APK الآن')),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () => openUrl(widget.project.repoUrl), icon: const Icon(Icons.code), label: const Text('فتح Repository')),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () => openUrl(actions), icon: const Icon(Icons.build), label: const Text('فتح GitHub Actions')),
          const SizedBox(height: 24),
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('بعد نجاح البناء ستجد app-release.apk داخل Artifact باسم Repository-apk.'))),
        ],
      ),
    );
  }
}
