import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../database/app_database.dart';
import '../models/project.dart';
import '../services/github_auth_service.dart';
import '../services/github_service.dart';
import '../widgets/app_scaffold.dart';

class ProjectDetailsScreen extends StatefulWidget {
  const ProjectDetailsScreen({super.key, required this.projectId});
  final int projectId;
  @override State<ProjectDetailsScreen> createState() => _ProjectDetailsScreenState();
}
class _ProjectDetailsScreenState extends State<ProjectDetailsScreen> {
  Project? project; Map<String, dynamic>? run; bool loading = true, busy = false;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await AppDatabase.instance.getProject(widget.projectId);
    if (mounted) setState(() { project = p; loading = false; });
  }
  Future<void> _build() async {
    if (project == null) return;
    final token = await GithubAuthService.instance.token(); if (token == null) return;
    setState(() => busy = true);
    try {
      final github = GithubService(token);
      await github.triggerBuild(project!.owner, project!.repoName);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تشغيل GitHub Actions.')));
      await Future.delayed(const Duration(seconds: 2));
      final r = await github.latestWorkflowRun(project!.owner, project!.repoName);
      if (mounted) setState(() => run = r);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _open(String url) async {
    final uri = Uri.tryParse(url); if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (project == null) return AppScaffold(title: 'المشروع', body: const Center(child: Text('المشروع غير موجود.')));
    return AppScaffold(title: project!.name, body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: ListTile(leading: const Icon(Icons.folder_copy), title: Text(project!.repoName), subtitle: Text('${project!.owner}/${project!.repoName}'))),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: busy ? null : _build, icon: const Icon(Icons.build), label: Text(busy ? 'جارٍ التشغيل...' : 'بناء APK الآن')),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () => _open(project!.repoUrl), icon: const Icon(Icons.open_in_new), label: const Text('فتح المستودع')),
      if (run != null) ...[
        const SizedBox(height: 20),
        Card(child: ListTile(
          leading: Icon(run!['conclusion'] == 'success' ? Icons.check_circle : Icons.info),
          title: Text(run!['name']?.toString() ?? 'Build'),
          subtitle: Text('${run!['status']} / ${run!['conclusion'] ?? 'قيد التنفيذ'}'),
          onTap: () => _open(run!['html_url'].toString()),
        )),
      ],
      const SizedBox(height: 20),
      const Text('بعد نجاح البناء، ستجد app-release.apk داخل Artifacts في GitHub Actions.', textAlign: TextAlign.center),
    ]));
  }
}
