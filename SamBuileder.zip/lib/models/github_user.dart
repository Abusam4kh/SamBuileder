class GithubUser {
  final String login;
  final String? name;
  final String? avatarUrl;
  final String htmlUrl;

  const GithubUser({
    required this.login,
    this.name,
    this.avatarUrl,
    required this.htmlUrl,
  });

  factory GithubUser.fromJson(Map<String, dynamic> json) => GithubUser(
    login: json['login'] as String? ?? '',
    name: json['name'] as String?,
    avatarUrl: json['avatar_url'] as String?,
    htmlUrl: json['html_url'] as String? ?? '',
  );
}
