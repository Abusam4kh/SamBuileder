class GithubUser {
  final String login;
  final String name;
  final String avatarUrl;
  const GithubUser({required this.login, required this.name, required this.avatarUrl});
  factory GithubUser.fromJson(Map<String, dynamic> json) => GithubUser(
    login: json['login'] as String? ?? '',
    name: json['name'] as String? ?? '',
    avatarUrl: json['avatar_url'] as String? ?? '',
  );
}
