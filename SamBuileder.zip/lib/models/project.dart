class Project {
  final int? id;
  final String name;
  final String repoName;
  final String owner;
  final String repoUrl;
  final String createdAt;
  final String status;
  const Project({
    this.id, required this.name, required this.repoName, required this.owner,
    required this.repoUrl, required this.createdAt, this.status = 'created',
  });
  Map<String, dynamic> toMap() => {
    'id': id, 'name': name, 'repo_name': repoName, 'owner': owner,
    'repo_url': repoUrl, 'created_at': createdAt, 'status': status,
  };
  factory Project.fromMap(Map<String, dynamic> m) => Project(
    id: m['id'] as int?, name: m['name'] as String,
    repoName: m['repo_name'] as String, owner: m['owner'] as String,
    repoUrl: m['repo_url'] as String, createdAt: m['created_at'] as String,
    status: (m['status'] as String?) ?? 'created',
  );
}
