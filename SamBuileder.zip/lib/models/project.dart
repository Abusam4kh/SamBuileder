class Project {
  final int? id;
  final String name;
  final String repoName;
  final String owner;
  final String repoUrl;
  final String status;
  final DateTime createdAt;

  const Project({
    this.id,
    required this.name,
    required this.repoName,
    required this.owner,
    required this.repoUrl,
    required this.status,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'name': name,
    'repo_name': repoName,
    'owner': owner,
    'repo_url': repoUrl,
    'status': status,
    'created_at': createdAt.toIso8601String(),
  };

  factory Project.fromMap(Map<String, Object?> map) => Project(
    id: map['id'] as int?,
    name: map['name'] as String,
    repoName: map['repo_name'] as String,
    owner: map['owner'] as String,
    repoUrl: map['repo_url'] as String,
    status: map['status'] as String,
    createdAt: DateTime.parse(map['created_at'] as String),
  );
}
