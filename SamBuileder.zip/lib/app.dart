import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/github_screen.dart';
import 'screens/create_project_screen.dart';
import 'screens/project_details_screen.dart';

class FlutterGithubBuilderApp extends StatelessWidget {
  const FlutterGithubBuilderApp({super.key});
  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF1565C0);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter GitHub Builder',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(), filled: true,
        ),
      ),
      routes: {
        '/': (_) => const HomeScreen(),
        '/github': (_) => const GithubScreen(),
        '/create': (_) => const CreateProjectScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/project') {
          return MaterialPageRoute(
            builder: (_) => ProjectDetailsScreen(projectId: settings.arguments as int),
          );
        }
        return null;
      },
    );
  }
}
