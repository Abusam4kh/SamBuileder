import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class GithubAuthService {
  GithubAuthService._();
  static final instance = GithubAuthService._();
  static const _key = 'github_token';
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  Future<void> saveToken(String token) =>
      _storage.write(key: _key, value: token.trim());

  Future<String?> getToken() => _storage.read(key: _key);

  Future<void> deleteToken() => _storage.delete(key: _key);

  Future<bool> isConnected() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }
}
