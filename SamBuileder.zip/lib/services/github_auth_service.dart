import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../models/github_user.dart';

class GithubAuthService {
  GithubAuthService._();
  static final instance = GithubAuthService._();
  static const _tokenKey = 'github_token';
  final _storage = const FlutterSecureStorage();

  Future<String?> token() => _storage.read(key: _tokenKey);

  Future<GithubUser?> validateAndSaveToken(String value) async {
    final token = value.trim();
    if (token.isEmpty) throw Exception('أدخل رمز GitHub أولاً.');
    final response = await http.get(Uri.parse('https://api.github.com/user'), headers: _headers(token));
    if (response.statusCode != 200) throw Exception('رمز GitHub غير صالح أو لا يملك الصلاحيات المطلوبة.');
    final user = GithubUser.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
    await _storage.write(key: _tokenKey, value: token);
    return user;
  }

  Future<GithubUser?> currentUser() async {
    final token = await token();
    if (token == null) return null;
    final response = await http.get(Uri.parse('https://api.github.com/user'), headers: _headers(token));
    if (response.statusCode != 200) return null;
    return GithubUser.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
  }

  Future<void> disconnect() => _storage.delete(key: _tokenKey);

  Map<String, String> _headers(String token) => {
    'Accept': 'application/vnd.github+json',
    'Authorization': 'Bearer $token',
    'X-GitHub-Api-Version': '2026-03-10',
  };
}
