import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/github_user.dart';
import 'github_auth_service.dart';

class GithubService {
  GithubService._();
  static final instance = GithubService._();
  static const base = 'https://api.github.com';

  Future<Map<String, String>> _headers() async {
    final token = await GithubAuthService.instance.getToken();
    if (token == null || token.isEmpty) throw Exception('لم يتم ربط حساب GitHub.');
    return {
      'Accept': 'application/vnd.github+json',
      'Authorization': 'Bearer $token',
      'X-GitHub-Api-Version': '2022-11-28',
      'Content-Type': 'application/json',
    };
  }

  Future<GithubUser> getCurrentUser() async {
    final r = await http.get(Uri.parse('$base/user'), headers: await _headers());
    _check(r);
    return GithubUser.fromJson(jsonDecode(r.body) as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> createRepository({
    required String name,
    required String description,
    required bool isPrivate,
  }) async {
    final r = await http.post(
      Uri.parse('$base/user/repos'),
      headers: await _headers(),
      body: jsonEncode({
        'name': name,
        'description': description,
        'private': isPrivate,
        'auto_init': false,
      }),
    );
    _check(r);
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<void> createFile({
    required String owner,
    required String repo,
    required String path,
    required String content,
    required String message,
  }) async {
    final r = await http.put(
      Uri.parse('$base/repos/$owner/$repo/contents/$path'),
      headers: await _headers(),
      body: jsonEncode({
        'message': message,
        'content': base64Encode(utf8.encode(content)),
      }),
    );
    _check(r);
  }

  Future<void> uploadFiles({
    required String owner,
    required String repo,
    required Map<String, String> files,
  }) async {
    for (final entry in files.entries) {
      await createFile(
        owner: owner,
        repo: repo,
        path: entry.key,
        content: entry.value,
        message: 'Add ${entry.key}',
      );
    }
  }

  Future<void> triggerWorkflow({
    required String owner,
    required String repo,
  }) async {
    final r = await http.post(
      Uri.parse('$base/repos/$owner/$repo/actions/workflows/build-apk.yml/dispatches'),
      headers: await _headers(),
      body: jsonEncode({'ref': 'main'}),
    );
    _check(r);
  }

  void _check(http.Response r) {
    if (r.statusCode >= 200 && r.statusCode < 300) return;
    String message = 'GitHub API error: ${r.statusCode}';
    try {
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      if (data['message'] != null) message = data['message'].toString();
    } catch (_) {}
    throw Exception(message);
  }
}
