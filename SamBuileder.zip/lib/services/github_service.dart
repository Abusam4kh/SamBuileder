import 'dart:convert';
import 'package:http/http.dart' as http;

class GithubService {
  GithubService(this.token);
  final String token;
  static const api = 'https://api.github.com';
  Map<String, String> get headers => {
    'Accept': 'application/vnd.github+json',
    'Authorization': 'Bearer $token',
    'X-GitHub-Api-Version': '2026-03-10',
    'Content-Type': 'application/json',
  };

  Future<Map<String, dynamic>> createRepository({
    required String name, required String description, required bool isPrivate,
  }) async {
    final r = await http.post(Uri.parse('$api/user/repos'), headers: headers,
      body: jsonEncode({'name': name, 'description': description, 'private': isPrivate,
        'has_issues': true, 'has_projects': false, 'has_wiki': false}));
    if (r.statusCode != 201) throw Exception(_error(r));
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<void> uploadFile({
    required String owner, required String repo, required String path,
    required String content, required String message,
  }) async {
    final r = await http.put(
      Uri.parse('$api/repos/$owner/$repo/contents/${path.split('/').map(Uri.encodeComponent).join('/')}'),
      headers: headers,
      body: jsonEncode({'message': message, 'content': base64Encode(utf8.encode(content))}),
    );
    if (r.statusCode != 201 && r.statusCode != 200) throw Exception('فشل رفع $path: ${_error(r)}');
  }

  Future<Map<String, dynamic>> latestWorkflowRun(String owner, String repo) async {
    final r = await http.get(Uri.parse('$api/repos/$owner/$repo/actions/runs?per_page=1'), headers: headers);
    if (r.statusCode != 200) throw Exception(_error(r));
    final data = jsonDecode(r.body) as Map<String, dynamic>;
    final runs = data['workflow_runs'] as List<dynamic>;
    return runs.isEmpty ? {} : runs.first as Map<String, dynamic>;
  }

  Future<void> triggerBuild(String owner, String repo, {String branch = 'main'}) async {
    final r = await http.post(Uri.parse('$api/repos/$owner/$repo/actions/workflows/build-apk.yml/dispatches'),
      headers: headers, body: jsonEncode({'ref': branch}));
    if (r.statusCode != 204) throw Exception(_error(r));
  }

  String _error(http.Response r) {
    try { return (jsonDecode(r.body) as Map<String, dynamic>)['message']?.toString() ?? 'HTTP ${r.statusCode}'; }
    catch (_) { return 'HTTP ${r.statusCode}'; }
  }
}
