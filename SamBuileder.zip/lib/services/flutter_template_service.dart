class FlutterTemplateService {
  static Map<String, String> buildProjectFiles({required String projectName}) {
    final name = _packageName(projectName);
    return {
      'pubspec.yaml': '''name: $name
description: Flutter project created by Flutter GitHub Builder.
publish_to: "none"
version: 1.0.0+1

environment:
  sdk: ">=3.10.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0

flutter:
  uses-material-design: true
''',
      'lib/main.dart': '''import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: Center(
            child: Text('تم إنشاء مشروع Flutter بنجاح'),
          ),
        ),
      ),
    );
  }
}
''',
      'README.md': '# $projectName\n\nمشروع Flutter تم إنشاؤه بواسطة Flutter GitHub Builder.\n',
      '.gitignore': '''.dart_tool/
.packages
.pub/
build/
.flutter-plugins
.flutter-plugins-dependencies
.gradle/
.idea/
*.iml
local.properties
''',
      '.github/workflows/build-apk.yml': _workflow(),
    };
  }

  static String _packageName(String value) {
    var s = value.toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9_]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_+|_+$'), '');
    if (s.isEmpty) s = 'my_flutter_app';
    if (RegExp(r'^[0-9]').hasMatch(s)) s = 'app_$s';
    return s;
  }

  static String _workflow() => r'''name: Build Android APK

on:
  workflow_dispatch:
  push:
    branches:
      - main
      - master

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Setup Flutter
        uses: subosito/flutter-action@v2
        with:
          flutter-version: "3.38.1"
          channel: stable
          cache: true

      - name: Versions
        run: |
          flutter --version
          dart --version

      - name: Recreate Android platform
        run: |
          rm -rf android
          flutter create --platforms=android --org com.sambuilder .

      - name: Get dependencies
        run: flutter pub get

      - name: Analyze
        run: flutter analyze

      - name: Build APK
        run: flutter build apk --release

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ${{ github.event.repository.name }}-apk
          path: build/app/outputs/flutter-apk/app-release.apk
          if-no-files-found: error
          retention-days: 30
''';
}
