class FlutterTemplateService {
  static Map<String, String> files(String appName) {
    final safe = _dartIdentifier(appName);
    return {
      'pubspec.yaml': _pubspec(appName, safe),
      'lib/main.dart': _main(appName),
      'README.md': _readme(appName),
      '.gitignore': _gitignore,
      '.github/workflows/build-apk.yml': _workflow,
    };
  }
  static String _dartIdentifier(String value) {
    var s = value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '_');
    s = s.replaceAll(RegExp(r'_+'), '_').replaceFirst(RegExp(r'^_+'), '');
    if (s.isEmpty) s = 'my_flutter_app';
    if (RegExp(r'^[0-9]').hasMatch(s)) s = 'app_$s';
    return s;
  }
  static String _pubspec(String title, String name) => '''
name: $name
description: $title - Flutter project built with Flutter GitHub Builder.
publish_to: "none"
version: 1.0.0+1
environment:
  sdk: ">=3.12.0 <4.0.0"
dependencies:
  flutter:
    sdk: flutter
dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^6.0.0
flutter:
  uses-material-design: true
''';
  static String _main(String title) => '''
import 'package:flutter/material.dart';
void main() => runApp(const MyApp());
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: '$title',
    locale: const Locale('ar'),
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1565C0)),
    home: const HomePage(),
  );
}
class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('$title')),
      body: const Center(child: Text('مشروع Flutter جاهز للبناء عبر GitHub Actions')),
    ),
  );
}
''';
  static const _readme = '''# Flutter Project
تم إنشاء هذا المشروع بواسطة Flutter GitHub Builder.
الناتج: `app-release.apk`
''';
  static const _gitignore = '''
.dart_tool/
.pub/
build/
.idea/
*.iml
android/.gradle/
android/local.properties
''';
  static const _workflow = '''
name: Build APK
on:
  workflow_dispatch:
  push:
    branches: [ "main" ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          channel: stable
          cache: true
      - name: Create Android platform
        run: flutter create --platforms=android --project-name="${{ github.event.repository.name }}" .
      - run: flutter pub get
      - name: Build release APK
        run: flutter build apk --release --split-per-abi=false
      - run: cp build/app/outputs/flutter-apk/app-release.apk app-release.apk
      - uses: actions/upload-artifact@v4
        with:
          name: ${{ github.event.repository.name }}-apk
          path: app-release.apk
          if-no-files-found: error
''';
}
