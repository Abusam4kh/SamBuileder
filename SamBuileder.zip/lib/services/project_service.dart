import 'github_auth_service.dart';
import 'github_service.dart';
import 'flutter_template_service.dart';
import '../database/app_database.dart';
import '../models/project.dart';

class ProjectService {
  final db = AppDatabase.instance;
  final auth = GithubAuthService.instance;
  Future<Project> createProject({
    required String name, required String repoName, required String description,
    required bool isPrivate, void Function(String message)? onProgress,
  }) async {
    final token = await auth.token();
    if (token == null) throw Exception('يجب ربط GitHub أولاً.');
    final user = await auth.currentUser();
    if (user == null) throw Exception('جلسة GitHub غير صالحة.');
    final github = GithubService(token);
    onProgress?.call('إنشاء المستودع...');
    final repo = await github.createRepository(name: repoName, description: description, isPrivate: isPrivate);
    final files = FlutterTemplateService.files(name);
    var i = 0;
    for (final entry in files.entries) {
      i++;
      onProgress?.call('رفع الملفات ($i/${files.length})...');
      await github.uploadFile(owner: user.login, repo: repoName, path: entry.key,
        content: entry.value, message: 'Initial Flutter project');
    }
    final project = Project(
      name: name, repoName: repoName, owner: user.login,
      repoUrl: repo['html_url'] as String? ?? 'https://github.com/${user.login}/$repoName',
      createdAt: DateTime.now().toIso8601String(),
    );
    final saved = await db.insertProject(project);
    onProgress?.call('تم إنشاء المشروع ورفع الملفات.');
    return saved;
  }
}
