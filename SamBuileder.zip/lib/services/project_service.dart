import '../database/app_database.dart';
import '../models/project.dart';
import 'flutter_template_service.dart';
import 'github_service.dart';

class ProjectService {
  ProjectService._();
  static final instance = ProjectService._();
  final _github = GithubService.instance;
  final _db = AppDatabase.instance;

  Future<Project> createProject({
    required String name,
    required String repoName,
    required String description,
    required bool isPrivate,
  }) async {
    final user = await _github.getCurrentUser();
    final repo = await _github.createRepository(
      name: repoName,
      description: description,
      isPrivate: isPrivate,
    );
    final owner = ((repo['owner'] as Map?)?['login'] as String?) ?? user.login;
    await _github.uploadFiles(
      owner: owner,
      repo: repoName,
      files: FlutterTemplateService.buildProjectFiles(projectName: name),
    );

    final project = Project(
      name: name,
      repoName: repoName,
      owner: owner,
      repoUrl: repo['html_url'] as String? ?? '',
      status: 'تم الإنشاء والرفع',
      createdAt: DateTime.now(),
    );
    await _db.insertProject(project);
    return project;
  }

  Future<List<Project>> getProjects() => _db.getProjects();

  Future<void> buildProject(Project project) =>
      _github.triggerWorkflow(owner: project.owner, repo: project.repoName);

  Future<void> deleteProject(Project project) async {
    if (project.id != null) await _db.deleteProject(project.id!);
  }
}
